Hi, user.

I hope you enjoy using this free predictor I made for you.
This took me a bit to make so I hope you enjoy
Don't skid pls ;(
i love u notris !!


-- my socials --
my discord: coxy.57
telegram: @Birdfar
-- my socials --

- coxy.57

HOW TO MAKE IT WORK (if ur on pc):
 1. You have to install python and click both options when installing.
 2. Once you installed,
 - Install all modules using: pip install (modulename) in cmd prompt (administrator)

IF THERE ARE ANY ISSUES WITH INSTALLING A MODULE:
Look it up on google, usually stack overflow or some other website tells you.

